// Package login provides functions to decode and encode Minecraft login requests found in the Login packet
// connection request. The JWT chain found in this connection request may also be verified using this
// package.
package login
